package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IRoleDto;
import com.example.service.security.Entity.Role;

@Repository
public interface IRoleRepository extends IBaseRepositoy< Role, Long> {
	@Query(value = " SELECT " + "	id," + "	name as role," + " description, " + " state " + "	FROM " + "	role "
			+ "	WHERE " + " deleted_at IS NULL", nativeQuery = true)
	List<IRoleDto> getList();

	@Query(value = " SELECT " + "	id," + "	name as role," + " description, " + " state " + "	FROM " + "	role "
			+ "	WHERE " + " deleted_at IS NULL", nativeQuery = true)
	List<Object[]> getDList();
}
