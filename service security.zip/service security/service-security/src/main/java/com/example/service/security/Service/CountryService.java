package com.example.service.security.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import com.example.service.security.Entity.Country;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ICountryRepository;
import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.IService.ICountryService;

@Service
public class CountryService extends ABaseService<Country> {

	@Autowired
	public ICountryRepository repository;
	@Override
	protected IBaseRepositoy<Country, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
		
	}
	
	@Override
	public List <ICountryDto> getListCountrys() {
	//TODO Auto-generated method stub
	return repository.getListCountrys();
}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
		
}

}