package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IViewDto;
import com.example.service.security.Entity.View;

@Repository
public interface IViewRepository extends IBaseRepositoy<View, Long> {
	
	@Query(value = " SELECT " + "	id," + "	name as view," + " description, " + " route, " + " state " + "	FROM "
			+ "	view " + "	WHERE " + " deleted_at IS NULL", nativeQuery = true)
	List<IViewDto> getList();

	@Query(value = " SELECT " + "	id," + "	name as view," + " description, " + " route, " + " state " + "	FROM "
			+ "	view " + "	WHERE " + " deleted_at IS NULL", nativeQuery = true)
	List<Object[]> getDList();
}
