package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ICompanyDto;
import com.example.service.security.Entity.Company;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ICompanyRepository;
import com.example.service.security.IService.ICompanyService;

@Service
public class CompanyService extends ABaseService< Company> implements ICompanyService {
	@Autowired
	private ICompanyRepository repository;

	@Override
	public List<ICompanyDto> getList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected IBaseRepositoy<Company, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	
	}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}
}
