package com.example.service.security.Dto;

public interface IModuleDto extends IGenericDto {
	

}
