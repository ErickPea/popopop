package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class inventarioDetalle extends ABaseEntity{

	@Column(name="Cantidad",nullable=false, unique=false)
	private String Cantidad;
	
	@Column(name="PrecioUnitario",nullable=false, unique=false)
	private String PrecioUnitario;
	
	@Column(name="InsumoProducto",nullable=false, unique=false)
	private String InsumoProducto;
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "inventario_id", nullable = false)
	private Inventario inventario;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "insumoproducto_id", nullable = false)
	private InsumoProducto insumoproducto;
	
	
	public InsumoProducto getInsumoproducto() {
		return insumoproducto;
	}

	public void setInsumoproducto(InsumoProducto insumoproducto) {
		this.insumoproducto = insumoproducto;
	}

	public String getCantidad() {
		return Cantidad;
	}

	public void setCantidad(String cantidad) {
		Cantidad = cantidad;
	}

	public String getPrecioUnitario() {
		return PrecioUnitario;
	}

	public void setPrecioUnitario(String precioUnitario) {
		PrecioUnitario = precioUnitario;
	}

	public String getInsumoProducto() {
		return InsumoProducto;
	}

	public void setInsumoProducto(String insumoProducto) {
		InsumoProducto = insumoProducto;
	}

	public Inventario getInventario() {
		return inventario;
	}

	public void setInventario(Inventario inventario) {
		this.inventario = inventario;
	}
	
	
	
}
