package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.IPositionDto;
import com.example.service.security.Entity.Position;

public interface IPositionService extends IBaseService<Position>{
	
	List<IPositionDto> getListPositions();
	
}
