package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.Entity.Country;

public interface ICountryService extends IBaseService<Country> {
	List <ICountryDto> getListCountrys();

}
