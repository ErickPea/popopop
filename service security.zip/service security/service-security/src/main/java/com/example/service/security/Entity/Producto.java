package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name="producto")
public class Producto extends ABaseEntity{
	@Column(name="Nombre",nullable=false, unique=false)
	private String Nombre;
	
	@Column(name="Precio",nullable=false, unique=false)
	private String Precio;
	
	@Column(name="Codigo",nullable=false, unique=false)
	private String Codigo;
	
	@Column(name="Cantidad",nullable=false, unique=false)
	private String Cantidad;
	
	@Column(name="PrecioCosto",nullable=false, unique=false)
	private String PrecioCosto;

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getPrecio() {
		return Precio;
	}

	public void setPrecio(String precio) {
		Precio = precio;
	}

	public String getCodigo() {
		return Codigo;
	}

	public void setCodigo(String codigo) {
		Codigo = codigo;
	}

	public String getCantidad() {
		return Cantidad;
	}

	public void setCantidad(String cantidad) {
		Cantidad = cantidad;
	}

	public String getPrecioCosto() {
		return PrecioCosto;
	}

	public void setPrecioCosto(String precioCosto) {
		PrecioCosto = precioCosto;
	}
	
	
}
