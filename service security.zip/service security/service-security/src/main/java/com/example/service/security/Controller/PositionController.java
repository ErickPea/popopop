package com.example.service.security.Controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Controller.ABaseController;
import com.example.service.security.Entity.Position;
import com.example.service.security.IService.IPositionService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/position")
public class PositionController extends ABaseController<Position,IPositionService>{

	protected PositionController(IPositionService service) {
		super(service, "Position");
		// TODO Auto-generated constructor stub
	}

}