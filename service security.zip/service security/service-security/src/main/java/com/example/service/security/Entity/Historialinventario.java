package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name= "historialinventario ")
public class Historialinventario extends ABaseEntity{
	
@Column (name="Code",nullable=false, unique=false) 
private String code;

}
