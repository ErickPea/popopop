package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.IPersonDto;
import com.example.service.security.Entity.Person;

public interface IPersonService extends IBaseService<Person>{

	List<IPersonDto> getList();
	List<IPersonDto> getTypeDocument(String type);
	public void updatePersonCustomer (Long personId, Person person);
	
	
}
