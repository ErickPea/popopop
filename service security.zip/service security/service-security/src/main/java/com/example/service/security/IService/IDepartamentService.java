package com.example.service.security.IService;

import java.util.List;
import com.example.service.security.Entity.Departament;
import com.example.service.security.Dto.IDepartamentDto;
public interface IDepartamentService extends IBaseService<Departament>{
	

	List<IDepartamentDto> getListDepartaments();
	
}
