package com.example.service.security.Dto;

import com.example.service.security.Entity.Person;

public interface ICustomerDto  extends IGenericDto{
	String getCode();
	 Person getPerson();

}
