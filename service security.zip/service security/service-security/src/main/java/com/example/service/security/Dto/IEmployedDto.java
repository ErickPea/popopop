package com.example.service.security.Dto;

public interface IEmployedDto extends IGenericDto {
	

	String getSalary();
}
