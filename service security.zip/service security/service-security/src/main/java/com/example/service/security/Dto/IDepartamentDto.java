package com.example.service.security.Dto;

public interface IDepartamentDto extends IGenericDto {
	 
	String getName_departament();
	String getCode_departament();
	String getCountry();
}
