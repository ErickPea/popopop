package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IPositionDto;
import com.example.service.security.Entity.Position;

@Repository
public interface IPositionRepository  extends IBaseRepositoy< Position, Long>{
	@Query(value = "SELECT " + 
            "    p.id, " + 
            "    p.created_at, " + 
            "    p.created_by, " + 
            "    p.deleted_at, " + 
            "    p.deleted_by, " + 
            "    p.state, " + 
            "    p.updated_at, " + 
            "    p.updated_by, " +
            "    p.name, " +
            "    p.code " + 
            "FROM " + 
            "    service_security.position p", 
    nativeQuery = true)
List<IPositionDto> getListPositions();

}
