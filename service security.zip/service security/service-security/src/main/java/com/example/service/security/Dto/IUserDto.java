package com.example.service.security.Dto;

import java.util.List;

public interface IUserDto  extends IGenericDto{
	
	Long getId();
	String getUsername();
	String getPersonname();
	String getPersonEmail();
	Long getRole();
	
	List<IModuleDto> getModules();
	void setModules(List<IModuleDto> modules);
}
