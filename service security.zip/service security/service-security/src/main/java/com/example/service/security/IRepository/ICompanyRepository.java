package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Entity.Company;
import com.example.service.security.Dto.ICompanyDto;
@Repository
public interface ICompanyRepository extends IBaseRepositoy<Company, Long> {
	
	@Query(value = "SELECT " + 
	        "    c.id, " + 
	        "    c.created_at, " + 
	        "    c.created_by, " + 
	        "    c.deleted_at, " +
	        "    c.deleted_by, " + 
	        "    c.state, " + 
	        "    c.updated_at, " + 
	        "    c.updated_by, " + 
	        "    c.nit, " +
	        "    c.rs, " +
	        "    c.phone, " +
	        "    c.address, " +
	        "    c.email, " + 
	        "    c.wed, " + 
	        "    c.city_id " +
	        "FROM " +
	        "    service_security.company c", 
	nativeQuery = true)
	List<ICompanyDto> getList();
}
