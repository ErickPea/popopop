package com.example.service.security.IService;
import java.util.List;
import com.example.service.security.Entity.Customer;
import com.example.service.security.Entity.Person;
import com.example.service.security.Dto.ICustomerDto;

public interface ICustomerService extends IBaseService<Customer> {
	List<ICustomerDto> getList();
	  public String GenerateCodeCustomer(long idPerson) throws Exception ;
		
		public void update(Long id, Customer entity) throws Exception;

		public Customer savePersonCustomer(Person entity) throws Exception;

	}
