package com.example.service.security.IService;

import com.example.service.security.Entity.View;

import java.util.List;

import com.example.service.security.Dto.IViewDto;
public interface IViewService extends IBaseService<View>{

	List<IViewDto> getList();
}
