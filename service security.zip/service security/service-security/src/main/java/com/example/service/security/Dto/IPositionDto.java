package com.example.service.security.Dto;

public interface IPositionDto extends IGenericDto {
	
	String getCode();
	String getName();
	}
