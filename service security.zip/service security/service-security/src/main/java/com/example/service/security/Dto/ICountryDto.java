package com.example.service.security.Dto;

public interface ICountryDto extends IGenericDto {
	String getName_country();
	String getCodee_country();
}
