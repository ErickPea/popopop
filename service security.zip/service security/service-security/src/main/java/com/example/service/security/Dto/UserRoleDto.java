package com.example.service.security.Dto;

public interface UserRoleDto extends IGenericDto {
	
	String getUser();
	String getRole();

}
