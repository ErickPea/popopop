package com.example.service.security.Utils;

public enum Type_Document {
	
	cedula,
	tarjeta_identidad,
	pasaporte,
	registroCivil
	

}
