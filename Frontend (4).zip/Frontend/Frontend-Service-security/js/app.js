const inputs = document.querySelectorAll(".input-field");
const toggle_btn = document.querySelectorAll(".toggle");
const main = document.querySelector("main");
const bullets = document.querySelectorAll(".bullets span");
const images = document.querySelectorAll(".image");
let slideIndex = 1;
let slideInterval;

inputs.forEach((inp) => {
  inp.addEventListener("focus", () => {
    inp.classList.add("active");
  });
  inp.addEventListener("blur", () => {
    if (inp.value != "") return;
    inp.classList.remove("active");
  });
});

toggle_btn.forEach((btn) => {
  btn.addEventListener("click", () => {
    main.classList.toggle("./view/User.html");
  });
});

function moveSlider() {
  let index = this.dataset.value;

  // Si el elemento clickeado es el enlace "Sign up", redirige a user.html
  if (this.id === 'registro') {
    window.open('./view/User.html', '_blank');
    return;
  }

  showSlides(slideIndex = index);
}

function showSlides(n) {
  images.forEach((img) => img.classList.remove("show"));
  const currentImage = document.querySelector(`.img-${n}`);
  currentImage.classList.add("show");

  const textSlider = document.querySelector(".text-group");
  textSlider.style.transform = `translateY(${-(n - 1) * 2.2}rem)`;

  bullets.forEach((bull) => bull.classList.remove("active"));
  bullets[n - 1].classList.add("active");
}

function autoSlide() {
  showSlides(slideIndex);
  slideIndex++;
  if (slideIndex > images.length) { slideIndex = 1 }
}

slideInterval = setInterval(autoSlide, 5000); // Cambia de imagen cada 5 segundos
autoSlide(); // Iniciar cambio automático de diapositivas

bullets.forEach((bullet) => {
  bullet.addEventListener("click", moveSlider);
});

const registro = document.getElementById('registro');

registro.addEventListener('click', (event) => {
  event.preventDefault(); // Evita que el enlace se siga por defecto
  window.open('./view/User.html', '_blank'); // Redirige al usuario a user.html
});
