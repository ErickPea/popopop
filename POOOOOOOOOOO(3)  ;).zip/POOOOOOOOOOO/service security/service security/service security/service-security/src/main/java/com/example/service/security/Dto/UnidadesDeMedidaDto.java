package com.example.service.security.Dto;

public interface UnidadesDeMedidaDto extends IGenericDto {
	String getNombre();
	String getCodigo();
}
