package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.service.security.Dto.IModuleDto;
import com.example.service.security.Entity.Module;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IModuleRepository;
import com.example.service.security.IService.IModuleService;

@Service
public class ModuleService extends ABaseService<Module> implements IModuleService{

	@Override
	public IBaseRepositoy<Module, Long> getRepository() {
		return repository;
	}
	
	@Override
	public void delete(Long id) {
	    repository.deleteById(id);
	}
	
	@Autowired
	public IModuleRepository repository;

	@Override
	public List<IModuleDto> getList() {
		return repository.getList();
	}

		
}