package com.example.service.security.Dto;

import com.example.service.security.Entity.Customer;
import com.example.service.security.Entity.Producto;

public interface FacturaDto extends IGenericDto {
	Producto getProducto();

	String getTotal();

	String getFecha();

	Customer getCustomer();
}
