package com.example.service.security.Controller;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.UnidadesDeMedidaDto;
import com.example.service.security.Entity.UnidadesDeMedida;
import com.example.service.security.IService.IUnidadesDeMedidaService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/unidadesdemedida")
public class UnidadesDeMedidaController extends ABaseController<UnidadesDeMedida, IUnidadesDeMedidaService>{

	public UnidadesDeMedidaController(IUnidadesDeMedidaService service) {
		super(service, "UnidadesDeMedida");
		// TODO Auto-generated constructor stub
	}
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<UnidadesDeMedidaDto>>> show(){
		
		try {
			List<UnidadesDeMedidaDto> entity =service.getUnidadesDeMedidaDto();
			return ResponseEntity.ok(new ApiResponseDto<List<UnidadesDeMedidaDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<UnidadesDeMedidaDto>>(e.getMessage(), null, false));
			
		}
	}
	
}
