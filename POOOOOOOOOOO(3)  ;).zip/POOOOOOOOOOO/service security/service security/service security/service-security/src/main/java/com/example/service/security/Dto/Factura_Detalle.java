package com.example.service.security.Dto;

import com.example.service.security.Entity.Factura;

public interface Factura_Detalle extends IGenericDto {
	Factura getFactura();

	String getNombre();

	String getCodigo();

	String getSupTotal();

	String getPrecioProducto();

	String getDescuento();

	String getIVA();

	String getEstado();

}
