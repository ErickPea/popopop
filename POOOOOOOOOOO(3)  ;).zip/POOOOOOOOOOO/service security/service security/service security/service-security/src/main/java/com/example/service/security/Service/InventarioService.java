package com.example.service.security.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.InventarioDto;
import com.example.service.security.Entity.Inventario;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.InventarioRepository;
import com.example.service.security.IService.IInventarioService;
@Service
public class InventarioService extends ABaseService<Inventario> implements IInventarioService {

	@Override
	public List<InventarioDto> getListInventarioDto() {
		// TODO Auto-generated method stub
		return repository.getListInventarioDto();
	}
	
	
@Autowired
public InventarioRepository repository;


	@Override
	public IBaseRepositoy<Inventario, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	public void delete(Long id) {
		repository.deleteById(id);
	}
	
}
