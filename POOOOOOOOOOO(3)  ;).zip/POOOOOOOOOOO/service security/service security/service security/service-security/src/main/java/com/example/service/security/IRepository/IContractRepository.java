package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IContractDto;
import com.example.service.security.Entity.Contract;
@Repository
public interface IContractRepository extends IBaseRepositoy<Contract, Long> {

	@Query(value = "SELECT " + "    c.id, " + "    c.created_at, " + "    c.created_by, " + "    c.deleted_at, "
			+ "    c.deleted_by, " + "    c.state, " + "    c.updated_at, " + "    c.updated_by, " + "    c.code, "
			+ "    c.salary, " + "    c.object, " + "    c.employed_id, " + "    c.company_id, " + "    c.start_date, "
			+ "    c.end_date " + "FROM " + "    service_security.contract c", nativeQuery = true)
	List<IContractDto> getList();

}
