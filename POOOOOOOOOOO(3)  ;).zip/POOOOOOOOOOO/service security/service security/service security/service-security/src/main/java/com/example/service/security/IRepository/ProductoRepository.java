package com.example.service.security.IRepository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.ProductoDto;
import com.example.service.security.Entity.Producto;
@Repository
public interface ProductoRepository extends IBaseRepositoy<Producto, Long>{
	
	
	@Query(value = "SELECT p.id AS id_producto,\n" +
			"       p.created_at AS created_at,\n" +
			"       p.created_by AS created_by,\n" +
			"       p.deleted_at AS deleted_at,\n" +
			"       p.deleted_by AS deleted_by,\n" +
			"       p.updated_at AS updated_at,\n" +
			"       p.updated_by AS updated_by,\n" +
			
			"       p.codigo AS codigo_producto,\n" +
			"       p.nombre AS nombre_producto,\n" +
			"       p.precio AS precio_producto,\n" +
			"       p.cantidad AS cantidad_producto,\n" +
			"       p.precio_costo AS precio_costo_producto\n" +
			"FROM Producto p", nativeQuery = true)
	public List<ProductoDto> getListProducto();
}
