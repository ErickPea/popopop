package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.IContractDto;
import com.example.service.security.Entity.Contract;

public interface IContractService extends IBaseService<Contract> {

	List<IContractDto> getList();

}
