package com.example.service.security.Service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.Histrial_InventarioDto;
import com.example.service.security.Entity.Historialinventario;
import com.example.service.security.IRepository.Historial_InventarioRepository;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IService.IHistorialInventarioService;
@Service
public class Historial_InventarioService extends ABaseService<Historialinventario> implements IHistorialInventarioService {

	@Override
	public List<Histrial_InventarioDto> getHistrial_InventarioDto() {
		// TODO Auto-generated method stub
		return repository.getHistrial_InventarioDto();
	}

	@Autowired
	public Historial_InventarioRepository  repository;
	
	@Override
	public IBaseRepositoy<Historialinventario, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	
	
}
