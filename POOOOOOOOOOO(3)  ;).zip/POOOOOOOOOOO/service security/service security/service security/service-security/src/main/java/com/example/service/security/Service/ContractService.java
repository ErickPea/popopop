package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.IContractDto;
import com.example.service.security.Entity.Contract;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IContractRepository;
import com.example.service.security.IService.IContractService;

@Service
public class ContractService extends ABaseService<Contract> implements IContractService {

	@Autowired
	public IContractRepository repository;

	@Override
	public List<IContractDto> getList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IBaseRepositoy<Contract, Long> getRepository() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}
}
