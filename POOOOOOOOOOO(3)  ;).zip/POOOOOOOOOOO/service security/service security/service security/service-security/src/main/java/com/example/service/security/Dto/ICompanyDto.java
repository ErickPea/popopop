package com.example.service.security.Dto;

public interface ICompanyDto extends IGenericDto {

	String getNit();

	String getDireccion();

	String getTelefono();

	String getCorreo();

	String getWeb();

}
