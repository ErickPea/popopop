package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IEmployedDto;
import com.example.service.security.Entity.Employed;

@Repository
public interface IEmployedRepository extends IBaseRepositoy<Employed, Long> {

	@Query(value = "SELECT " + "    e.id, " + "    e.created_at, " + "    e.created_by, " + "    e.deleted_at, "
			+ "    e.deleted_by, " + "    e.state, " + "    e.updated_at, " + "    e.updated_by, " + "    e.salary, "
			+ "    e.person_id, " + "    e.company_id, " + "    e.position_id " + "FROM "
			+ "    service_security.employed e", nativeQuery = true)
	List<IEmployedDto> getList();

}
