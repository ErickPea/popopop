package com.example.service.security.Dto;

import com.example.service.security.Entity.UnidadesDeMedida;

public interface InsumoDto {
	String getNombre();

	String getDescripcion();

	UnidadesDeMedida getUnidadesDeMedida();
}
