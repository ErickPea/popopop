package com.example.service.security.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.FacturaDto;
import com.example.service.security.Entity.Factura;
import com.example.service.security.IService.IFacturaService;
import org.springframework.web.bind.annotation.GetMapping;
@CrossOrigin(origins="*")
@RestController
@RequestMapping("v1/api/factura")
public class FacturaController extends ABaseController<Factura, IFacturaService>{

	public FacturaController(IFacturaService service) {
		super(service,"Factura");
		// TODO Auto-generated constructor stub
	}

	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<FacturaDto>>> show(){
		
		try {
			List<FacturaDto> entity =service.getFacturaDto();
			return ResponseEntity.ok(new ApiResponseDto<List<FacturaDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<FacturaDto>>(e.getMessage(), null, false));
			
		}
	}
	
}
