package com.example.service.security.Dto;

import com.example.service.security.Entity.Producto;

public interface InventarioDto extends IGenericDto {

	String getNombre();

	String getDescripcion();

	String getCodigo();

	String getFechaEntrada();

	String getFechaSalida();

	Producto getProducto();

}
