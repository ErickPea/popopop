package com.example.service.security.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.IUserDto;
import com.example.service.security.Dto.UserRoleDto;
import com.example.service.security.Entity.Role;
import com.example.service.security.Entity.User;
import com.example.service.security.Entity.UserRole;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.UserRolReposittory;
import com.example.service.security.IService.IUserRolService;
import com.example.service.security.IService.IUserService;
@Service
public class UserRolService extends ABaseService<UserRole> implements IUserRolService {


	
	@Autowired
	private UserRolReposittory repository; 
	
@Override
	public IBaseRepositoy<UserRole, Long> getRepository() {
		// TODO Auto-generated method stub
		return  repository;
	}

public List<UserRoleDto> getListUserRoleDto() {
    List<UserRole> userRoles = getRepository().findAll();
    return userRoles.stream()
                     .map(this::convertToUserRoleDto)
                     .collect(Collectors.toList());
}
private UserRoleDto convertToUserRoleDto(UserRole userRole) {
    UserRoleDto userRoleDto = new UserRoleDto() {
        @Override
        public Long getId() {
            return userRole.getId();
        }

        @Override
        public Boolean getState() {
            return userRole.getState();
        }

        @Override
        public User getUser() {
            return userRole.getUser();
        }

        @Override
        public Role getRol() {
            return userRole.getRol();
        }
    };

    return userRoleDto;
}
}
