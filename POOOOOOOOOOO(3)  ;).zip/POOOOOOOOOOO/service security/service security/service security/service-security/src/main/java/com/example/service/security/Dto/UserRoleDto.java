package com.example.service.security.Dto;

import com.example.service.security.Entity.Role;
import com.example.service.security.Entity.User;

public interface UserRoleDto extends IGenericDto {

	User getUser();

	Role getRol();

}
