package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "insumoproducto")
public class InsumoProducto extends ABaseEntity {

	@Column(name = "Cantidad", nullable = false, unique = false)
	private String Cantidad;

	@Column(name = "Adicional", nullable = false, unique = false)
	private String Adicional;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "producto_id", nullable = false)
	private Producto producto;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "insumo_id", nullable = false)
	private Insumo insumo;

	public String getCantidad() {
		return Cantidad;
	}

	public void setCantidad(String cantidad) {
		Cantidad = cantidad;
	}

	public String getAdicional() {
		return Adicional;
	}

	public void setAdicional(String adicional) {
		Adicional = adicional;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public Insumo getInsumo() {
		return insumo;
	}

	public void setInsumo(Insumo insumo) {
		this.insumo = insumo;
	}

}
