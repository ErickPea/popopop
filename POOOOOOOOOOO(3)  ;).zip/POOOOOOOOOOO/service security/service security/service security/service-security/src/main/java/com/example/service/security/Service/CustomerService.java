package com.example.service.security.Service;

import java.time.LocalDate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Service.ABaseService;
import com.example.service.security.Service.PersonService;
import com.sena.servicesecurity.IRepository.IBaseRepository;
import com.example.service.security.Dto.ICustomerDto;
import com.example.service.security.Dto.IPersonDto;
import com.example.service.security.Entity.Customer;
import com.example.service.security.Entity.Person;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ICustomerRepository;
import com.example.service.security.IService.ICustomerService;
import com.example.service.security.Dto.IPersonDto;
@Service
public class CustomerService extends ABaseService<Customer> implements ICustomerService{
	
	@Override
	protected IBaseRepositoy<Customer, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	@Override
	public List<ICustomerDto> getListICustomerDto() {
		// TODO Auto-generated method stub
		return repository.getListICustomerDto();
	}
	
	//List<ICustomerDto> getListICustomerDto();
	@Override
	public String GenerateCodeCustomer(long idPerson) throws Exception {
		
		return null;}
	
	@Autowired
	private ICustomerRepository repository;
	
	@Autowired
	private PersonService personService;
	

	

	@Override
	public Customer save(Customer entity) throws Exception {
		try {
			
			Person personEntity = entity.getPerson();
  
			 IPersonDto person = repository.getDocument(entity.getPerson().getId());
             
			 String type = person.getTypeDocument();
			 String document = person.getDocument();
			 int anio = LocalDateTime.now().getYear();

            String documentDigit= document.substring(Math.max(0, document.length() -4));
			 String code= anio+"-"+type+"-"+documentDigit;

			 
		        
		        
		        if (person.getDocument() == null || person.getDocument().isEmpty()) {
		            throw new Exception("El campo document de la persona es obligatorio");
		        }
		    
		        
		       
		        entity.setCode(code);
		        entity.setCreatedAt(LocalDateTime.now());
		        entity.setCreatedBy((long) 1); // Cuando esté el logging, se debe enviar el ID del usuario con Auth
		        
		        // Guardar la entidad cliente
		        return getRepository().save(entity);
		    } catch (Exception e) {
		        // Captura la excepción
		        throw new Exception("Error al guardar la entidad: " + e.getMessage());
		    }
	}

	@Override
	public void update(Long id, Customer entity) throws Exception {
		 Optional<Customer> opClient = getRepository().findById(id);

		    if (opClient.isEmpty()) {
		        throw new Exception("Registro no encontrado");
		    } else if (opClient.get().getDeletedAt() != null) {
		        throw new Exception("Registro inhabilitado");
		    }

		    Person personUpdate = entity.getPerson();
		    personUpdate.setTypeDocument(entity.getPerson().getTypeDocument()); // Actualizar el tipo de documento
		    personUpdate.setDocument(entity.getPerson().getDocument()); // Actualizar el número de documento
		    personService.update(personUpdate.getId(), personUpdate);

		    Customer updatedClient = savePersonCustomer(personUpdate);
		    Customer existingClient = opClient.get();
		    existingClient.setCode(updatedClient.getCode());
		    existingClient.setPerson(updatedClient.getPerson());

		    String[] ignoreProperties = { "id", "createdAt", "deletedAt", "createdBy", "deletedBy" };
		    BeanUtils.copyProperties(entity, existingClient, ignoreProperties);

		    existingClient.setUpdatedAt(LocalDateTime.now());
		    existingClient.setUpdatedBy((long) 1);
		}

	@Override
	public String GenerateCodeCustomer(String typeDocument, String document, LocalDateTime date) 
			throws Exception {
			 	String documentDigit= document.substring(Math.max(0, document.length() -4));
			 	String code= date.getYear()+"-"+typeDocument+"-"+documentDigit;
				return code;
	}

	@Override
	public Customer savePersonCustomer(Person entity) throws Exception {
		try {
			Person person = personService.save(entity);
			Customer Customer = new Customer();
			String codeClient = GenerateCodeCustomer(person.getTypeDocument(), person.getDocument(), person.getCreatedAt() );	
			
			Customer.setCode(codeClient);
			Customer.setPerson(person);
			Customer.setState(true);
			Customer.setDeletedAt(LocalDateTime.now());
			Customer.setCreatedBy((long) 1);
			Customer Customer1 =getRepository().save(Customer);
			return Customer1;
			
			
			
		}catch (Exception e){
			throw new Exception ("Error al guardar la entidad:" +e.getMessage());
		}
	}

	

	

	
	
	
	
}
