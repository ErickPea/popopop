package com.example.service.security.IService;

import com.example.service.security.Utils.Type_Document;
import com.example.service.security.Utils.weekdays;

public interface IEnumService {

	Type_Document[] getDocument_Type();

	weekdays[] getWeekdays();

}
