package com.example.service.security.IRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.ICustomerDto;
import com.example.service.security.Dto.IPersonDto;
import com.example.service.security.Entity.Customer;


@Repository
public interface ICustomerRepository extends IBaseRepositoy<Customer, Long> {

	@Query(value = "SELECT "
	        + "c.id, "
	        + "c.code, "
	        + "CONCAT(p.first_name, ' ', p.last_name) AS name, "
	        + "p.type_document, "
	        + "p.document, "
	        + "p.id AS person_id, "
	        + "c.state "
	        + "FROM "
	        + "client c "
	        + "INNER JOIN person AS p ON p.id = c.person_id "
	        + "WHERE "
	        + "c.deleted_at IS NULL", nativeQuery = true)
	List<ICustomerDto> getListICustomerDto();



@Query(value = " SELECT  "
		+ " type_document, "
		+ " document "
		+ "	FROM  "
		+ "	person "
		+ "	WHERE  "
		+ " id = :id", nativeQuery = true)
IPersonDto getDocument(@Param("id") Long id);

@Query("SELECT c FROM Customer c WHERE c.person.id = :personId")
Optional<Customer> findByPersonId(@Param("personId") Long personId);

}

