package com.example.service.security.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.InsumoDto;
import com.example.service.security.Entity.Insumo;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.InsumoRepository;
import com.example.service.security.IService.IInsumoService;
@Service
public class InsumoService extends ABaseService<Insumo> implements IInsumoService{

	@Override
	public List<InsumoDto> getInsumoDto() {
		// TODO Auto-generated method stub
		return repository.getInsumoDto() ;
	}
	
@Autowired
public InsumoRepository repository;

	@Override
	protected IBaseRepositoy<Insumo, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	

}
