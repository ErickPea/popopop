package com.example.service.security.IRepository;

import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.Histrial_InventarioDto;
import com.example.service.security.Entity.Historialinventario;
@Repository
public interface Historial_InventarioRepository extends IBaseRepositoy<Historialinventario, Long>{
	 @Query(value = "SELECT hi.id AS id_historial, " +
	            "hi.codigo AS codigo_historial, " +
	            "id.cantidad AS cantidad, " +
	            "id.precioUnitario AS precio_unitario " +
	            "FROM HistorialInventario hi " +
	            "INNER JOIN InventarioDetalle id ON hi.InventarioDetalleId = id.Id", nativeQuery = true)
	
	List<Histrial_InventarioDto> getHistrial_InventarioDto();
}
