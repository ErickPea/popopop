package com.example.service.security.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.Dto.IPersonDto;
import com.example.service.security.Entity.Customer;
import com.example.service.security.Entity.Person;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ICustomerRepository;
import com.example.service.security.IRepository.IPersonRepository;
import com.example.service.security.IService.IPersonService;

@Service
public class PersonService extends ABaseService<Person> implements IPersonService {

    @Autowired
    public IPersonRepository repository;
    
    
    @Override
    public IBaseRepositoy<Person, Long> getRepository() {
        return repository;
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<IPersonDto> getList() {
        return repository.getList();
    }
    
    
    public void update(Long id, Person entity) throws Exception {
    	
    	
        Optional<Person> op = getRepository().findById(id);

        if (op.isEmpty()) {
            throw new Exception("Registro no encontrado");
        } else if (op.get().getDeletedAt() != null) {
            throw new Exception("Registro inhabilitado");
        }

        Person entityUpdate = op.get();

        String[] ignoreProperties = { "id", "createdAt", "deletedAt", "createdBy", "deletedBy" };
        BeanUtils.copyProperties(entity, entityUpdate, ignoreProperties);
        entityUpdate.setUpdatedAt(LocalDateTime.now());
        entityUpdate.setUpdatedBy((long)1); //Cuanto esté el loggin, se debe enviar el ID del usuario con Auth
        getRepository().save(entityUpdate);
    }

	@Override
	public List<IPersonDto> getTypeDocument(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updatePersonCustomer(Long personId, Person person) {
		// TODO Auto-generated method stub
		
	}

	
    
    

    
    
}