package com.example.service.security.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.InsumoProductoDto;
import com.example.service.security.Entity.InsumoProducto;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.InsumoProductoRepository;
import com.example.service.security.IService.IInsumoProductoService;
@Service
public class InsumoProductoService extends ABaseService<InsumoProducto> implements IInsumoProductoService{

	@Override
	public List<InsumoProductoDto> getInsumoProductoDto() {
		// TODO Auto-generated method stub
		return reposiroty.getInsumoProductoDto();
	}
	
@Autowired
public InsumoProductoRepository reposiroty;

	@Override
	public IBaseRepositoy<InsumoProducto, Long> getRepository() {
		// TODO Auto-generated method stub
		return reposiroty;
	}

}
