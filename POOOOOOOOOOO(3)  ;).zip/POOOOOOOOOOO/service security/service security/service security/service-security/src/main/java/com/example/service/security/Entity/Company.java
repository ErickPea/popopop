package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Company ")
public class Company extends ABaseEntity {

	@Column(name = "nit", length = 50, nullable = false)
	private String Nit;

	@Column(name = "rs", length = 50, nullable = false)
	private String Rs;

	@Column(name = "address", length = 50, nullable = false)
	private String Address;

	@Column(name = "phone", length = 50, nullable = false)
	private String phone;

	@Column(name = "email", length = 50, nullable = false)
	private String Email;

	@Column(name = "wed", length = 50, nullable = false)
	private String Wed;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "city_id", nullable = false)
	private City city;

	public String getNit() {
		return Nit;
	}

	public void setNit(String nit) {
		Nit = nit;
	}

	public String getRs() {
		return Rs;
	}

	public void setRs(String rs) {
		Rs = rs;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getWed() {
		return Wed;
	}

	public void setWed(String wed) {
		Wed = wed;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

}
