package com.example.service.security.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.IService.IEmployedService;
import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.IEmployedDto;
import com.example.service.security.Entity.Employed;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/employed")
public class EmployedController extends ABaseController<Employed, IEmployedService> {

	public EmployedController(IEmployedService service) {
		super(service, "Employed");
		// TODO Auto-generated constructor stub
	}

	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<IEmployedDto>>> show() {
		try {
			List<IEmployedDto> entity = service.getList();
			return ResponseEntity.ok(new ApiResponseDto<List<IEmployedDto>>("Registro encontrado", entity, true));
		} catch (Exception e) {
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<IEmployedDto>>(e.getMessage(), null, false));
		}
	}
}
