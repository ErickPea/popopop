package com.example.service.security.Dto;

public interface ICityDto extends IGenericDto {
	String getName_city();

	String getCode_city();

	String getDepartamet();

}
