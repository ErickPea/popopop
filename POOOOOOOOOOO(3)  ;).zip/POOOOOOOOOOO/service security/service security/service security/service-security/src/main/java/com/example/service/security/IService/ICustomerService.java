package com.example.service.security.IService;

import java.time.LocalDateTime;
import java.util.List;
import com.example.service.security.Entity.Customer;
import com.example.service.security.Entity.Person;
import com.example.service.security.Dto.ICustomerDto;

public interface ICustomerService extends IBaseService<Customer> {
	List<ICustomerDto> getListICustomerDto();

	public String GenerateCodeCustomer(long idPerson) throws Exception;

	public void update(Long id, Customer entity) throws Exception;

	public Customer savePersonCustomer(Person entity) throws Exception;

	public String GenerateCodeCustomer(String typeDocument, String document, LocalDateTime date) throws Exception;

}
