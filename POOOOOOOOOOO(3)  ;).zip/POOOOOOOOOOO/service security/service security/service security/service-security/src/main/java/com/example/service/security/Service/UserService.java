package com.example.service.security.Service;

import com.example.service.security.Dto.IModuleDto;
import com.example.service.security.Dto.IUserDto;
import com.example.service.security.Dto.IViewDto;
import com.example.service.security.Entity.User;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IUserRepository;
import com.example.service.security.IService.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService extends ABaseService<User> implements IUserService {

    @Autowired
    public IUserRepository userRepository;

    @Override
    public IBaseRepositoy<User, Long> getRepository() {
        return userRepository;
    }
    
    @Override
    public void delete(Long id) {
        userRepository.deleteById(id);
    }
	



    @Override
    public Optional<IUserDto> getUserWithViews(String username, String password) {
    	
        List<IUserDto> userDtoList = userRepository.getUserWithRole(username, password);

        if (!userDtoList.isEmpty()) {
            IUserDto userDto = userDtoList.get(0);
            
            Long roleId = userDto.getRole();
            
            System.out.println(userDto);
            
            List<IViewDto> views = userRepository.getViewsByRoleId(roleId);
            
            
            
            
            System.out.println(roleId);
            // Crear una implementación concreta de IUserDto y llenarla con los datos obtenidos
           
            IUserDto dto = new IUserDto() {
                @Override
                public Long getId() {
                    return userDto.getId();
                }

                

                

                @Override
                public String getPersonEmail() {
                    return userDto.getPersonEmail();
                }

                @Override
                public Boolean getState() {
                    return userDto.getState();
                }

               

				@Override
				public void setModules(List<IModuleDto> model) {
					// TODO Auto-generated method stub
					
				}

				

				@Override
				public String getPersonname() {
					// TODO Auto-generated method stub
					return userDto.getPersonname();
				}

				@Override
				public Long getRole() {
					// TODO Auto-generated method stub
					return userDto.getRole();
				}

				@Override
				public List<IModuleDto> getModules() {
					// TODO Auto-generated method stub
					return null;
				}


				@Override
				public void getUsername(String username) {
					// TODO Auto-generated method stub
					
				}





				@Override
				public String getUsername() {
					// TODO Auto-generated method stub
					return null;
				}

				

			

          

                
            };

            return Optional.of(dto);
        } else {
            return Optional.empty();
        }
    }



    
    
    
   

    
}
