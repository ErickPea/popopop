package com.example.service.security.IRepository;
import com.example.service.security.Entity.Insumo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.InsumoDto;
@Repository
public interface InsumoRepository extends IBaseRepositoy<Insumo, Long>{
	@Query(value = "SELECT id AS id_insumo, nombre AS nombre_insumo,"
			+ " descripcion AS descripcion_insumo "
			+ "FROM Insumo", nativeQuery = true)
	List<InsumoDto> getInsumoDto();

}
