package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ICityDto;
import com.example.service.security.Entity.City;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ICityRepository;
import com.example.service.security.IService.ICityService;

@Service
public class CityService extends ABaseService<City> implements ICityService {

	@Override
	public IBaseRepositoy<City, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	@Autowired
	public ICityRepository repository;

	@Override
	public List<ICityDto> GetListCitys() {
		// TODO Auto-generated method stub
		return repository.GetListCitys();
	}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}

}
