package com.example.service.security.IService;

import com.example.service.security.Entity.detalle_factura;

import java.util.List;

import com.example.service.security.Dto.Factura_Detalle;

public interface IFactura_DetalleService extends IBaseService<detalle_factura> {

	
	
	List<Factura_Detalle> getFactura_Detalle();
}
