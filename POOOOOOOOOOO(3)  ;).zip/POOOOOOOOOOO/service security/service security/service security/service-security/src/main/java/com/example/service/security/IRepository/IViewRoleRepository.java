package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.ViewRolDto;
import com.example.service.security.Entity.ViewRole;
@Repository
public interface IViewRoleRepository extends IBaseRepositoy<ViewRole, Long> {
	
}
