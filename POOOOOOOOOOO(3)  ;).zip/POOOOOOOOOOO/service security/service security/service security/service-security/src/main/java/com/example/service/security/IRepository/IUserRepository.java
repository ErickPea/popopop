package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IModuleDto;
import com.example.service.security.Dto.IUserDto;
import com.example.service.security.Dto.IViewDto;
import com.example.service.security.Entity.User;

@Repository
public interface IUserRepository extends IBaseRepositoy<User, Long> {

	@Query(value = "SELECT \r\n" + "    u.id, \r\n" + "    u.username AS username, \r\n"
			+ "    CONCAT(p.first_name, ' ', p.last_name) AS personName, \r\n" + "    p.email AS personEmail, \r\n"
			+ "    u.state,\r\n" + "    ur.role_id AS roleId -- Selecciona el ID del rol\r\n" + "FROM \r\n"
			+ "    user u\r\n" + "INNER JOIN \r\n" + "    person p ON p.id = u.person_id\r\n" + "INNER JOIN \r\n"
			+ "    user_role ur ON ur.user_id = u.id\r\n" + "INNER JOIN \r\n" + "    role r ON r.id = ur.role_id\r\n"
			+ "WHERE \r\n" + "    u.username = :username AND u.password = :password\r\n" + "", nativeQuery = true)
	List<IUserDto> getUserWithRole(@Param("username") String username, @Param("password") String password);

	@Query(value = "SELECT v.id, v.description, v.state, v.name, v.route, m.name AS module " + "FROM view AS v "
			+ "INNER JOIN module_view AS mv ON mv.view_id = v.id " + "INNER JOIN module AS m ON m.id = mv.module_id "
			+ "INNER JOIN view_role AS vr ON vr.view_id = v.id " + "WHERE vr.role_id = :roleId", nativeQuery = true)
	List<IViewDto> getViewsByRoleId(@Param("roleId") Long roleId);

	@Query(value = "SELECT \r\n" + "    m.id AS moduleId, \r\n" + "    m.name AS moduleName, \r\n"
			+ "    m.description AS moduleDescription, \r\n" + "    m.state AS moduleState, \r\n"
			+ "    JSON_ARRAYAGG(JSON_OBJECT('viewId', v.id, 'viewName', v.name, 'viewRoute', v.route, 'viewDescription', v.description)) AS views\r\n"
			+ "FROM \r\n" + "    module m \r\n" + "INNER JOIN \r\n" + "    module_view mv ON mv.module_id = m.id\r\n"
			+ "INNER JOIN \r\n" + "    view v ON mv.view_id = v.id\r\n" + "GROUP BY m.id", nativeQuery = true)
	List<IModuleDto> getAllModulesWithViews();

}
