package com.example.service.security.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.UnidadesDeMedidaDto;
import com.example.service.security.Entity.UnidadesDeMedida;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.UnidadesDeMedidaRepository;
import com.example.service.security.IService.IUnidadesDeMedidaService;
@Service
public class UnidadesDeMedidaService extends ABaseService<UnidadesDeMedida> implements IUnidadesDeMedidaService {

	@Override
	public List<UnidadesDeMedidaDto> getUnidadesDeMedidaDto() {
		// TODO Auto-generated method stub
		return repository.getUnidadesDeMedidaDto();
	}
@Autowired
public UnidadesDeMedidaRepository repository;
	
	@Override
	public IBaseRepositoy<UnidadesDeMedida, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	
	
}
