package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.Dto.IDepartamentDto;
import com.example.service.security.Entity.Departament;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IDepartamentRepository;
import com.example.service.security.IService.IDepartamentService;

@Service
public class DepartmentService  extends ABaseService<Departament> implements IDepartamentService{

	
	@Autowired
	public IDepartamentRepository repository;

	@Override
	public List<IDepartamentDto> getListDepartaments() {
		// TODO Auto-generated method stub
		return repository.getListDepartaments();
	}
	
	@Override
	public void delete(Long id) {
	    repository.deleteById(id);
	}

	@Override
	public IBaseRepositoy<Departament, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	
}

