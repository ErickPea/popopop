package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "detalle_factura ")
public class detalle_factura extends ABaseEntity {

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "factura_id", nullable = false)
	private Factura factura;

	@Column(name = "Nombre", nullable = false, unique = false)
	private String Nombre;

	@Column(name = "Codigo", nullable = false, unique = false)
	private String Codigo;

	@Column(name = "SupTotal", nullable = false, unique = false)
	private String SupTotal;

	@Column(name = "PrecioProducto", nullable = false, unique = false)
	private String PrecioProducto;

	@Column(name = "Descuento", nullable = false, unique = false)
	private String Descuento;

	@Column(name = "IVA", nullable = false, unique = false)
	private String IVA;

	@Column(name = "Estado", nullable = false, unique = false)
	private String Estado;

	public Factura getFactura() {
		return factura;
	}

	public void setFactura(Factura factura) {
		this.factura = factura;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getCodigo() {
		return Codigo;
	}

	public void setCodigo(String codigo) {
		Codigo = codigo;
	}

	public String getSupTotal() {
		return SupTotal;
	}

	public void setSupTotal(String supTotal) {
		SupTotal = supTotal;
	}

	public String getPrecioProducto() {
		return PrecioProducto;
	}

	public void setPrecioProducto(String precioProducto) {
		PrecioProducto = precioProducto;
	}

	public String getDescuento() {
		return Descuento;
	}

	public void setDescuento(String descuento) {
		Descuento = descuento;
	}

	public String getIVA() {
		return IVA;
	}

	public void setIVA(String iVA) {
		IVA = iVA;
	}

	public String getEstado() {
		return Estado;
	}

	public void setEstado(String estado) {
		Estado = estado;
	}

}
