package com.example.service.security.Controller;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.ProvedorProductoDto;
import com.example.service.security.Entity.ProvedorProducto;
import com.example.service.security.IService.IProvedorProductoService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/provedorproducto")
public class ProvedorProductoController extends ABaseController<ProvedorProducto, IProvedorProductoService>{

	public ProvedorProductoController(IProvedorProductoService service) {
		super(service, "ProvedorProducto");
		// TODO Auto-generated constructor stub
	}
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<ProvedorProductoDto>>> show(){
		
		try {
			List<ProvedorProductoDto> entity =service.getListProvedorProducto();
			return ResponseEntity.ok(new ApiResponseDto<List<ProvedorProductoDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<ProvedorProductoDto>>(e.getMessage(), null, false));
			
		}
	}
	
	
}
