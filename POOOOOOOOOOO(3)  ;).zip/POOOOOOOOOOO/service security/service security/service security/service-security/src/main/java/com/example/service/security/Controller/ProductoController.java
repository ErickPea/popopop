package com.example.service.security.Controller;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.ProductoDto;
import com.example.service.security.Entity.Producto;
import com.example.service.security.IService.IProductoService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/producto")
public class ProductoController extends ABaseController<Producto, IProductoService>{

	public ProductoController(IProductoService service) {
		super(service, "Producto");
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<ProductoDto>>> show(){
		
		try {
			List<ProductoDto> entity =service.getListProducto();
			return ResponseEntity.ok(new ApiResponseDto<List<ProductoDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<ProductoDto>>(e.getMessage(), null, false));
			
		}
	}

	
	
}
