package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.FacturaDto;
import com.example.service.security.Entity.Factura;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.FacturaRepository;
import com.example.service.security.IService.IFacturaService;
@Service
public class FacturaService extends ABaseService<Factura> implements IFacturaService {

	@Override
	public IBaseRepositoy<Factura, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	@Autowired
	public FacturaRepository repository;

	@Override
	public List<FacturaDto> getFacturaDto(){
		return repository.getFacturaDto();
		
	}
	
	public void delete(Long id) {
		repository.deleteById(id);
	}

}
