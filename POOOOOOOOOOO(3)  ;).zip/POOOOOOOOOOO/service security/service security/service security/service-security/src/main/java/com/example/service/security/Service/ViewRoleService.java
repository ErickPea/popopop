package com.example.service.security.Service;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.UserRoleDto;
import com.example.service.security.Dto.ViewRolDto;
import com.example.service.security.Entity.Role;
import com.example.service.security.Entity.UserRole;
import com.example.service.security.Entity.View;
import com.example.service.security.Entity.ViewRole;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IViewRoleRepository;
import com.example.service.security.IService.IViewRoleService;
@Service
public class ViewRoleService extends ABaseService<ViewRole> implements IViewRoleService{

	
	
	
@Autowired
public IViewRoleRepository repository;


	@Override
	public IBaseRepositoy<ViewRole, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	@Override
	public List<ViewRolDto> getListViewRole() {
	    List<ViewRole> ViewRoles = getRepository().findAll();
	    return ViewRoles.stream()
	                     .map(this::convertToViewRolDto)
	                     .collect(Collectors.toList());
	    }
	    
	private ViewRolDto convertToViewRolDto(ViewRole viewRole) {
	    return new ViewRolDto() {
	        @Override
	        public Long getId() {
	            return viewRole.getId();
	        }

	        @Override
	        public Boolean getState() {
	            return viewRole.getState();
	        }

	        @Override
	        public View getView() {
	            return viewRole.getView();
	        }

	        @Override
	        public Role getRole() {
	            return viewRole.getRole();
	        }
	    };
	}
}
