package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.InventarioDetalle;
import com.example.service.security.Entity.inventarioDetalle;

public interface IInventarioDetalleService extends IBaseService<inventarioDetalle> {
	List<InventarioDetalle> getInventarioDetalle();
}
