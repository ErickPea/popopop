package com.example.service.security.IService;

import com.example.service.security.Entity.Factura;

import java.util.List;

import com.example.service.security.Dto.FacturaDto;

public interface IFacturaService extends IBaseService<Factura> {
	List<FacturaDto> getFacturaDto();
}
